//Armo array de productos de oferta

/* const productos = [
    {
        "id":1,
        "imagen": "🚲",
        "nombre": "Bicicleta Ruta",
        "precio": 1000
    },
    {
        "id":2,
        "imagen": "🏍",
        "nombre": "Bicicleta Electrica",
        "precio": 1100
    },
    {
        "id":3,
        "imagen": "🛴",
        "nombre": "Monopatines",
        "precio": 350
    },
    {
        "id":4,
        "imagen": "🛹",
        "nombre": "Skates",
        "precio": 300
    },
    {
        "id":5,
        "imagen": "🌞",
        "nombre": "Anteojos Sol",
        "precio": 150
    },
    {
        "id":6,
        "imagen": "⚡",
        "nombre": "Energizantes",
        "precio": 30
    },
    {
        "id":7,
        "imagen": "⏱",
        "nombre": "Relojes",
        "precio": 650

    }
] */